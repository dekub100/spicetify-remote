import ctypes
import os
import subprocess
import sys
import time

import servicemanager
import win32event
import win32service
import win32serviceutil


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False

class SpicetifyRemoteService(win32serviceutil.ServiceFramework):
    _svc_name_ = "SpicetifyRemotePython"
    _svc_display_name_ = "Spicetify Remote Server (Python)"
    _svc_description_ = "Relay server for Spicetify remote control and OBS widget"
    # Setting the default startup type to Automatic
    _svc_startup_type_ = win32service.SERVICE_AUTO_START

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        self.process = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.hWaitStop)
        if self.process:
            self.process.terminate()

    def SvcDoRun(self):
        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE,
                              servicemanager.PYS_SERVICE_STARTED,
                              (self._svc_name_, ''))
        self.main()

    def main(self):
        server_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(server_dir)
        script_path = os.path.join(server_dir, "server.py")

        python_exe = sys.executable
        if not python_exe.endswith("python.exe"):
            python_exe = os.path.join(os.path.dirname(python_exe), "python.exe")

        self.process = subprocess.Popen([python_exe, script_path], cwd=project_root)

        while True:
            rc = win32event.WaitForSingleObject(self.hWaitStop, 5000)
            if rc == win32event.WAIT_OBJECT_0:
                break
            if self.process.poll() is not None:
                servicemanager.LogMsg(servicemanager.EVENTLOG_ERROR_TYPE,
                                      0xF000,
                                      ("Server process died unexpectedly. Restarting...", ''))
                self.process = subprocess.Popen([python_exe, script_path], cwd=project_root)

        if self.process:
            self.process.terminate()

if __name__ == '__main__':
    is_elevated_process = "--elevated" in sys.argv
    if is_elevated_process:
        sys.argv.remove("--elevated")

    if len(sys.argv) > 1 and sys.argv[1] in ['install', 'update', 'start', 'stop', 'remove', 'restart']:
        if not is_admin():
            print("Requesting administrator privileges...")
            args = sys.argv[:]
            args.append("--elevated")
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(args), None, 1)
            sys.exit()

    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        print("--- Spicetify Remote Service Tool ---")
        print(f"Executing: {command}...")

        try:
            win32serviceutil.HandleCommandLine(SpicetifyRemoteService)

            # Manual override for Automatic startup
            if command == 'install':
                hscm = win32service.OpenSCManager(None, None, win32service.SC_MANAGER_ALL_ACCESS)
                hs = win32service.OpenService(hscm, SpicetifyRemoteService._svc_name_, win32service.SERVICE_CHANGE_CONFIG)
                win32service.ChangeServiceConfig(
                    hs, win32service.SERVICE_NO_CHANGE,
                    win32service.SERVICE_AUTO_START,
                    win32service.SERVICE_NO_CHANGE, None, None, 0, None, None, None, None
                )
                print("Startup type forced to: Automatic")

            print(f"\nSUCCESS: Command '{command}' completed.")
        except SystemExit as e:
            if e.code == 0:
                print(f"\nSUCCESS: Service '{command}' successful.")
            else:
                print(f"\nERROR: Service '{command}' failed with code {e.code}.")
        except Exception as e:
            print(f"\nCRITICAL ERROR: {e}")

        if is_elevated_process:
            print("\n" + "="*40)
            print("Operation complete. This window will close in 10 seconds...")
            try:
                time.sleep(10)
            except KeyboardInterrupt:
                pass
    else:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(SpicetifyRemoteService)
        servicemanager.StartServiceCtrlDispatcher()
